export interface Equipo {
    id?: string,
    nombre: string,
    logo: string,
    estado: boolean
    jugadores: string[]
}
