export interface Jugador {
    id?: string,
    nombre: string,
    edad: number,
    apodo: string,
    foto: string,
    posicion: string,
    estado: boolean
}
